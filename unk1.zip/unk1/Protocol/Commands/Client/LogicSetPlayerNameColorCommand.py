from ByteStream.Reader import Reader
from Protocol.Messages.Server.LoginFailedMessage import LoginFailedMessage


class LogicSetPlayerNameColorCommand(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readVInt()
        self.readVInt()
        self.readLogicLong()
        self.name_color = self.readDataReference()[1]

    def process(self, db):
        if self.name_color not in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14]:
            return
        if self.name_color == 14 and not self.player.vip:
            LoginFailedMessage(self.client, self.player,
                               'Данный цвет имени можно установить только с VIP-статусом').send()
            return
        if self.name_color == 13:  # terminal gradient
            if not self.player.vip or self.player.high_trophies < 5000:
                LoginFailedMessage(self.client, self.player,
                                   'Данный цвет ника можно установить, имея VIP-статус и 5000 трофеев').send()
                return
        self.player.name_color = self.name_color
        db.update_player_account(self.player.token, 'NameColor', self.player.name_color)
