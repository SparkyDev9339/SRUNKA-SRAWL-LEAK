from ByteStream.Reader import Reader
from DataBase.MongoDB import MongoDB
from Protocol.Messages.Server.AllianceStreamMessage import AllianceStreamMessage
from Protocol.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Protocol.Messages.Server.AllianceResponseMessage import AllianceResponseMessage
from Protocol.Messages.Server.AllianceDataMessage import AllianceDataMessage
from Utils.Helpers import Helpers

MEMBER_ROLE = 1
SENIOR_ROLE = 3
VICE_PRESIDENT_ROLE = 4
PRESIDENT_ROLE = 2

PROMOTE = object()
PROMOTE_TO_PRESIDENT = object()
DEMOTE = object()


class PromoteAllianceMemberMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readInt()  # high id
        self.target_low_id = self.readInt()
        self.target_role = self.readVInt()

    def process(self, db: MongoDB):
        if self.target_role not in [MEMBER_ROLE, SENIOR_ROLE, VICE_PRESIDENT_ROLE, PRESIDENT_ROLE]:
            return

        Helpers.reload_player(self, db)
        if self.player.club_id == 0:
            self.client.close()
            return

        target_info = db.load_player_account_by_id(self.target_low_id)
        if not target_info or target_info['ClubID'] != self.player.club_id or self.player.club_role not in [2, 3]:
            self.client.close()
            return

        club_info = db.load_club(self.player.club_id)
        Helpers.load_club(self, club_info)

        if self.target_role == PRESIDENT_ROLE and self.player.club_role == PRESIDENT_ROLE:
            action = PROMOTE_TO_PRESIDENT
        elif target_info['ClubRole'] == MEMBER_ROLE:  # member
            action = PROMOTE
        elif target_info['ClubRole'] == SENIOR_ROLE:  # senior
            if self.target_role == 1:
                action = DEMOTE
            else:
                action = PROMOTE
        elif target_info['ClubRole'] == VICE_PRESIDENT_ROLE and self.player.club_role == PRESIDENT_ROLE:
            action = DEMOTE
            # повышение до президента мы отлавливаем выше
        else:
            self.client.close()
            return

        role_name = {
            MEMBER_ROLE: 'Участник',
            SENIOR_ROLE: 'Ветеран',
            VICE_PRESIDENT_ROLE: 'Вице-президент',
            PRESIDENT_ROLE: 'Президент',
        }[self.target_role]

        if action == PROMOTE:
            db.update_player_account(target_info['Token'], 'ClubRole', self.target_role)
            AllianceResponseMessage(self.client, self.player, 81).send()
            AllianceResponseMessage(self.client, self.player, 101).sendByID(target_info['ID'])

            message = {'Event': 2,
                       'Message': f'{self.player.name} повысил(а) {target_info["Name"]} '
                                  f'до роли {role_name}',
                       'PlayerID': 0,
                       'PlayerName': 'Service Bot',
                       'PlayerRole': 1,
                       'Tick': self.player.message_tick}

        elif action == DEMOTE:
            db.update_player_account(target_info['Token'], 'ClubRole', self.target_role)
            AllianceResponseMessage(self.client, self.player, 82).send()
            AllianceResponseMessage(self.client, self.player, 102).sendByID(target_info['ID'])

            message = {'Event': 2,
                       'Message': f'{self.player.name} понизил(а) {target_info["Name"]} '
                                  f'до роли {role_name}',
                       'PlayerID': 0,
                       'PlayerName': 'Service Bot',
                       'PlayerRole': 1,
                       'Tick': self.player.message_tick}
        else:
            self.player.club_role = VICE_PRESIDENT_ROLE
            db.update_player_account(self.player.token, 'ClubRole', self.player.club_role)
            db.update_player_account(target_info['Token'], 'ClubRole', PRESIDENT_ROLE)
            AllianceResponseMessage(self.client, self.player, 81).send()
            AllianceResponseMessage(self.client, self.player, 101).sendByID(target_info['ID'])

            message = {'Event': 2,
                       'Message': f'{self.player.name} передала(а) роль {role_name} '
                                  f'игроку {target_info["Name"]}',
                       'PlayerID': 0,
                       'PlayerName': 'Service Bot',
                       'PlayerRole': 1,
                       'Tick': self.player.message_tick}

        club_info['Messages'].append(message)
        db.update_club(self.player.club_id, 'Messages', club_info['Messages'])
        members = db.load_all_players({'ClubID': club_info['ID']})
        for member in members:
            AllianceDataMessage(self.client, self.player, members, club_info).sendByID(member['ID'])
            AllianceStreamMessage(self.client, self.player, [message]).sendByID(member['ID'])
