from ByteStream.Reader import Reader
from Protocol.Messages.Server.PlayerProfileMessage import PlayerProfileMessage
from Protocol.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Protocol.Messages.Server.BotProfileMessage import BotProfileMessage


class GetPlayerProfileMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.account_id = self.readLong()

    def process(self, db):
        if self.account_id == 0:
            BotProfileMessage(self.client, self.player).send()
        else:
            account_data = db.load_player_account_by_id(self.account_id)
            if not account_data:
                OutOfSyncMessage(self.client, self.player).send()
                return
            PlayerProfileMessage(self.client, self.player, account_data, db).send()
