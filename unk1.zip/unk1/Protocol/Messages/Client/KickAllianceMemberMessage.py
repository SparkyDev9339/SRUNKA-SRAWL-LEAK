from ByteStream.Reader import Reader
from DataBase.MongoDB import MongoDB
from Protocol.Messages.Server.AllianceResponseMessage import AllianceResponseMessage
from Protocol.Messages.Server.AllianceDataMessage import AllianceDataMessage
from Protocol.Messages.Server.AllianceStreamMessage import AllianceStreamMessage
from Protocol.Messages.Server.MyAllianceMessage import MyAllianceMessage
import time

from Utils.Helpers import Helpers


class KickAllianceMemberMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readInt()  # high id
        self.low_id = self.readInt()  # low id

    def process(self, db: MongoDB):
        Helpers.reload_player(self, db)
        target_info = db.load_player_account_by_id(self.low_id)

        if not target_info or target_info['ClubID'] != self.player.club_id or \
                target_info['ClubRole'] != 1 or self.player.club_role == 1:
            self.client.close()
            return
        db.update_player_account(target_info['Token'], 'ClubID', 0)

        club_info = db.load_club(self.player.club_id)
        club_info['BannedPlayers'][str(target_info['ID'])] = int(time.time()) + 86400
        db.update_club(self.player.club_id, 'BannedPlayers', club_info['BannedPlayers'])
        db.update_club_trophies(self.player.club_id)

        AllianceResponseMessage(self.client, self.player, 70).send()
        AllianceResponseMessage(self.client, self.player, 100).sendByID(target_info['ID'])
        MyAllianceMessage(self.client, self.player, {'ID': 0}).sendByID(target_info['ID'])

        Helpers.load_club(self, club_info)
        message = {'Event': 2,
                   'Message': f'{self.player.name} исключил(а) {target_info["Name"]}',
                   'PlayerID': 0,
                   'PlayerName': 'Service Bot',
                   'PlayerRole': 1,
                   'Tick': self.player.message_tick}
        club_info['Messages'].append(message)
        db.update_club(self.player.club_id, 'Messages', club_info['Messages'])

        members = db.load_all_players({'ClubID': club_info['ID']})
        for member in members:
            AllianceDataMessage(self.client, self.player, members, club_info).sendByID(member['ID'])
            AllianceStreamMessage(self.client, self.player, [message]).sendByID(member['ID'])
