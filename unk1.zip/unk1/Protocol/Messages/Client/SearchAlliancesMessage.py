from ByteStream.Reader import Reader
from Protocol.Messages.Server.AllianceListMessage import AllianceListMessage


class SearchAlliancesMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.query = self.readString()

    def process(self, db):
        clubs = list(
            filter(
                lambda x: self.query.lower() in x['Name'].lower(),
                db.load_all_clubs({})
            )
        )
        players_in_clubs = db.load_all_players({'ClubID': {'$ne': 0}})

        AllianceListMessage(self.client, self.player, self.query, clubs, players_in_clubs).send()
