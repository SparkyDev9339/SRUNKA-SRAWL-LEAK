from ByteStream.Reader import Reader
from Protocol.Messages.Server.AllianceResponseMessage import AllianceResponseMessage
from Protocol.Messages.Server.AllianceStreamMessage import AllianceStreamMessage
from Protocol.Messages.Server.MyAllianceMessage import MyAllianceMessage
from Protocol.Messages.Server.AllianceDataMessage import AllianceDataMessage
from Protocol.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Utils.Helpers import Helpers


class ChangeAllianceSettingsMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.club_id              = self.player.club_id
        self.club_desc            = self.readString()
        self.club_badge           = self.readDataReference()[1]
        self.club_region          = self.readDataReference()[1]
        self.club_type            = self.readVInt()
        self.club_req_trophies    = self.readVInt()
        self.club_family_friendly = self.readVInt()

    def process(self, db):
        club_data = db.load_club(db.load_player_account(self.player.token)['ClubID'])
        if club_data is None:
            OutOfSyncMessage(self.client, self.player).send()
            return
        player_info = db.load_player_account(self.player.token)
        self.player.club_id = player_info['ClubID']
        self.player.club_role = player_info['ClubRole']
        if self.player.club_role not in [2, 3]:
            OutOfSyncMessage(self.client, self.player).send()
            return

        self.club_desc = self.club_desc[:256].replace('<', '').replace('>', '')
        if self.club_type == 2:
            self.club_type = 3
        if self.club_req_trophies > 25000:
            self.club_req_trophies = 25000

        db.update_club(self.club_id, 'Description', self.club_desc)
        db.update_club(self.club_id, 'Type', self.club_type)
        db.update_club(self.club_id, 'BadgeID', self.club_badge)
        db.update_club(self.club_id, 'RequiredTrophies', self.club_req_trophies)

        Helpers.load_club(self, club_data)
        message = {'Event': 2,
                   'Message': f'{self.player.name} обновил(а) настройки клуба',
                   'PlayerID': 0,
                   'PlayerName': 'Service Bot',
                   'PlayerRole': 1,
                   'Tick': self.player.message_tick}
        club_data['Messages'].append(message)
        db.update_club(self.club_id, 'Messages', club_data['Messages'])

        club_data = db.load_club(self.club_id)

        MyAllianceMessage(self.client, self.player, club_data).send()
        AllianceResponseMessage(self.client, self.player, 10).send()
        members = db.load_all_players({'ClubID': club_data['ID']})
        for member in members:
            AllianceStreamMessage(self.client, self.player, [message]).sendByID(member['ID'])
            AllianceDataMessage(self.client, self.player, members, club_data).sendByID(member['ID'])
