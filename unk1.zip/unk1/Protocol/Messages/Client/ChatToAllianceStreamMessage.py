import time
from datetime import datetime
from hashlib import sha256
import json
from ByteStream.Reader import Reader
from Protocol.Messages.Server.AllianceStreamMessage import AllianceStreamMessage
from Protocol.Messages.Server.LoginFailedMessage import LoginFailedMessage
from Protocol.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Protocol.Messages.Server.ShutdownStartedMessage import ShutdownStartedMessage
from Utils.Helpers import Helpers


class ChatToAllianceStreamMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

        self.bot_msg = 'Перезайдите в игру, чтобы увидеть изменения.'
        self.send_ofs = False
        self.send_login_failed = False

    def decode(self):
        self.msg = self.readString()[:128]
        self.args = self.msg.strip().split()

    def process(self, db):
        club_data = db.load_club(self.player.club_id)

        if club_data is None:
            OutOfSyncMessage(self.client, self.player).send()
            return

        Helpers.load_club(self, club_data)

        if self.args[0].startswith('/'):
            self.process_command(db)

            if self.send_ofs:
                OutOfSyncMessage(self.client, self.player).send()
                return
            if self.send_login_failed:
                LoginFailedMessage(self.client, self.player, self.bot_msg).send()
                return
            # else
            message = {'Event': 2,
                       'Message': self.bot_msg,
                       'PlayerID': 0,
                       'PlayerName': 'Service Bot',
                       'PlayerRole': 1,
                       'Tick': self.player.message_tick}
            AllianceStreamMessage(self.client, self.player, [message]).send()
        else:
            message = {'Event': 2,
                       'Message': self.msg,
                       'PlayerID': self.player.ID,
                       'PlayerName': self.player.name,
                       'PlayerRole': self.player.club_role,
                       'Tick': self.player.message_tick}

            club_data['Messages'].append(message)
            club_data['Messages'] = club_data['Messages'][-50:]
            db.update_club(self.player.club_id, 'Messages', club_data['Messages'])

            for member in db.load_all_players({'ClubID': club_data['ID']}):
                member_id = member['ID']
                AllianceStreamMessage(self.client, self.player, [message]).sendByID(member_id)

    def process_command(self, db):
        if self.args[0] == '/help':
            self.bot_msg = ('Список команд:\n' +
                            '/help - эта справка\n' +
                            '/vip - наличие VIP\n' +
                            '/info - информация\n' +
                            '/online - количество онлайн игроков\n' +
                            '/link - привязать аккаунт к Telegram' +
                            '/unlink - отвязать аккаунт\n'
                            )
        elif self.args[0] == '/link':
            with open('config.json') as f:
                self.player.settings = json.load(f)
            if self.player.telegram_id != 0:
                self.bot_msg = 'Аккаунт уже привязан. Сначала отвяжите его с помощью команды /unlink'
            elif len(self.args) == 3 and self.args[1].isdigit():
                user_tg_id = self.args[1]
                user_hash = self.args[2]
                real_hash = sha256(
                    user_tg_id.encode()
                    + b'DICKDEV'
                    + str(datetime.utcnow().toordinal()).encode()
                ).hexdigest()[:12]
                if user_hash == real_hash:
                    db.update_player_account(self.player.token, 'TelegramID', int(user_tg_id))
                    # if self.player.name_color != 12:
                        # db.update_player_account(self.player.token, 'NameColor', 15)
                    if int(user_tg_id) in self.player.settings['VipPlayers']:
                        db.update_player_account(self.player.token, 'Vip', True)
                        self.bot_msg = f'Аккаунт {user_tg_id} привязан!\n' \
                                       'А так же вы успешно получили VIP-статус, привязанный к аккаунту!'
                    else:
                        self.bot_msg = f'Аккаунт {user_tg_id} успешно привязан!'
                    self.send_login_failed = True
                else:
                    self.bot_msg = 'Неверный ключ. Возможно, истёк срок его действия. ' \
                                   'Получите новый у @LboLinkBot'
            else:
                self.bot_msg = 'Для подключения аккаунта Telegram скопируйте команду у @LboLinkBot'
        elif self.args[0] == '/unlink':
            db.update_player_account(self.player.token, 'TelegramID', 0)
            self.bot_msg = 'Telegram-аккаунт успешно отвязан!'
            self.send_login_failed = True
        elif self.args[0] == '/vip':
            with open('config.json') as f:
                self.player.settings = json.load(f)
            if self.player.vip:
                self.bot_msg = 'У вас уже есть VIP-статус!'
            elif self.player.telegram_id in self.player.settings['VipPlayers']:
                db.update_player_account(self.player.token, 'Vip', True)
                self.bot_msg = 'Вы получили VIP-статус!\n' \
                               'Что он дает: @lbovip в Telegram'
                self.send_login_failed = True
            else:
                self.bot_msg = 'У вас нет VIP-статуса!\n' \
                               'Приобрести: @lbovip в Telegram'
        elif self.args[0] == '/info':
            self.bot_msg = 'Lucky Brawl Mods v2\n' \
                           'Приватный сервер от Lucky Brawl Originals\n' \
                           'Telegram: https://t.me/lborig\n\n' \
                           f'ID аккаунта: {self.player.ID}\n' \
                           f'Token: {self.player.token[:10]}\n' \
                           f'Telegram ID: {self.player.telegram_id}'
