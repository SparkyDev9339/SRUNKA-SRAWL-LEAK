from ByteStream.Reader import Reader
from Protocol.Messages.Server.BattleEndMessage import BattleEndMessage
import time


last_battleend_asks = {}


class AskForBattleEndMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.players = []

    def decode(self):
        self.result = self.readVInt()
        self.readVInt()  # unknown
        self.rank = self.readVInt()
        _, self.mapID = self.readDataReference()

        self.count = self.readVInt()

        for i in range(self.count):
            brawler = self.readDataReference()
            skin = self.readDataReference()
            team = self.readVInt()
            self.readVInt()  # unknown
            username = self.readString()

            self.players.append({
                'Name': username,
                'Team': team,
                'Brawler': brawler[1],
                'Skin': skin[1]
            })

    def process(self, db):
        if self.player.ID in last_battleend_asks:
            if (time.time() - last_battleend_asks[self.player.ID]) < 10:
                print(f'Cheats sus: {self.player.ID} (battle end abusing)')
                self.client.close()
                return
        last_battleend_asks[self.player.ID] = time.time()
        if self.rank != 0:
            if self.players[0]['Team'] == self.players[1]['Team']:
                self.type = 5
            else:
                self.type = 2
        else:
            self.type = 0

        BattleEndMessage(self.client, self.player, self.type,
                         self.result, self.rank, self.players, db).send()
