from ByteStream.Reader import Reader
from Protocol.Messages.Server.LeaderboardMessage import LeaderboardMessage


class GetLeaderboardMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.is_local = self.readBool()
        self.local_region = self.readVInt()
        self.type = self.readVInt()
        self.data_ref = self.readDataReference()

    def process(self, db):
        if self.type == 1:
            self.player.leaderboard_type = 1

            players = list(filter(
                lambda x: not x['IsBanned'] and x['Trophies'] > 0,
                db.load_all_players_sorted({}, 'Trophies')
            ))
            players.reverse()
            players = players[:200]

            clubs = db.load_all_clubs({})

            LeaderboardMessage(self.client, self.player, players, [], clubs).send()

        elif self.type == 2:
            self.player.leaderboard_type = 2

            clubs = db.load_all_clubs_sorted({}, 'Trophies')
            clubs.reverse()
            clubs = clubs[:50]

            players_in_clubs = db.load_all_players({'ClubID': {'$ne': 0}})

            LeaderboardMessage(self.client, self.player, clubs, players_in_clubs, []).send()

        elif False and self.type == 0 and self.data_ref[0] == 16:
            self.player.leaderboard_type = 1

            players = db.load_all_players({})
            filtered_p = []
            for plr in players:
                if not plr['IsBanned']:
                    brawler_trophy = plr['BrawlerTrophies'][self.data_ref[1]]
                    if brawler_trophy > 0:
                        plr['Trophies'] = brawler_trophy
                        filtered_p.append(plr)


            players = list(filter(
                lambda x: not x['IsBanned'],
                db.load_all_players_sorted({})
            ))
            players.reverse()
            players = players[:200]

            clubs = db.load_all_clubs({})

            LeaderboardMessage(self.client, self.player, players, [], clubs).send()
