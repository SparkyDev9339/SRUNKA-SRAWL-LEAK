from ByteStream.Reader import Reader
from Protocol.Messages.Server.BattleLogMessage import BattleLogMessage
from Protocol.Messages.Server.LoginFailedMessage import LoginFailedMessage
from Protocol.Messages.Server.ShutdownStartedMessage import ShutdownStartedMessage


class GetBattleLogMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, db):
        pass
        # ShutdownStartedMessage(self.client).send()
        # self.player.err_code = 10
        # LoginFailedMessage(self.client, self.player, 'Лог боёв пока что не реализован').send()
        # BattleLogMessage(self.client, self.player).send()
