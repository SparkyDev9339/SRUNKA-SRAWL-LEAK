import time
from Utils.Helpers import Helpers
from ByteStream.Reader import Reader
from Protocol.Messages.Server.AllianceResponseMessage import AllianceResponseMessage
from Protocol.Messages.Server.MyAllianceMessage import MyAllianceMessage
from Protocol.Messages.Server.AllianceStreamMessage import AllianceStreamMessage
from Protocol.Messages.Server.AllianceDataMessage import AllianceDataMessage
from Protocol.Messages.Server.OutOfSyncMessage import OutOfSyncMessage


class JoinAllianceMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.club_id = self.readLong()

    def process(self, db):
        Helpers.reload_player(self, db)
        if self.player.club_id != 0:
            AllianceResponseMessage(self.client, self.player, 44).send()
            return

        club_data = db.load_club(self.club_id)
        if club_data is None:
            OutOfSyncMessage(self.client, self.player).send()
            return

        current_time = int(time.time())
        players_bans = club_data['BannedPlayers']
        try:
            until_time_banned = players_bans[str(self.player.ID)]
        except KeyError:
            until_time_banned = 0

        members = db.load_all_players({'ClubID': club_data['ID']})
        if len(members) >= 50:
            AllianceResponseMessage(self.client, self.player, 42).send()
        elif club_data['Type'] == 3:
            AllianceResponseMessage(self.client, self.player, 43).send()
        elif self.player.trophies < club_data['RequiredTrophies']:
            AllianceResponseMessage(self.client, self.player, 45).send()
        elif current_time < until_time_banned:
            AllianceResponseMessage(self.client, self.player, 46).send()
        else:
            self.player.club_id = self.club_id
            self.player.club_role = 1

            db.update_player_account(self.player.token, 'ClubID', self.player.club_id)
            db.update_player_account(self.player.token, 'ClubRole', self.player.club_role)

            Helpers.load_club(self, club_data)
            message = {'Event': 2,
                       'Message': f'{self.player.name} вступил(а) в клуб',
                       'PlayerID': 0,
                       'PlayerName': 'Service Bot',
                       'PlayerRole': 1,
                       'Tick': self.player.message_tick}
            club_data['Messages'].append(message)
            db.update_club(self.player.club_id, 'Messages', club_data['Messages'])

            db.update_club_trophies(self.club_id)

            AllianceResponseMessage(self.client, self.player, 40).send()
            MyAllianceMessage(self.client, self.player, club_data).send()
            members = db.load_all_players({'ClubID': club_data['ID']})
            AllianceStreamMessage(self.client, self.player, club_data['Messages']).send()
            for member in members:
                if member['ID'] == self.player.ID:
                    continue
                AllianceDataMessage(self.client, self.player, members, club_data).sendByID(member['ID'])
                AllianceStreamMessage(self.client, self.player, [message]).sendByID(member['ID'])
