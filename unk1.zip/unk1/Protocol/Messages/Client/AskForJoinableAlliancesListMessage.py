import time

from ByteStream.Reader import Reader
from Protocol.Messages.Server.JoinableAllianceListMessage import JoinableAllianceListMessage
import random


class AskForJoinableAlliancesListMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, db):
        clubs = list(filter(
            lambda x: x['Type'] == 1 and self.player.trophies > x['RequiredTrophies'] and
            time.time() > x['BannedPlayers'].get(self.player.ID, 0),
            db.load_all_clubs({})
        ))
        random.shuffle(clubs)
        clubs = clubs[:10]

        JoinableAllianceListMessage(self.client, self.player, db, clubs).send()
