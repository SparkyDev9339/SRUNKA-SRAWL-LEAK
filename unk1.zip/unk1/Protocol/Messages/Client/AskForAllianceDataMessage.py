from ByteStream.Reader import Reader
from Protocol.Messages.Server.AllianceDataMessage import AllianceDataMessage
from Protocol.Messages.Server.OutOfSyncMessage import OutOfSyncMessage


class AskForAllianceDataMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.club_id = self.readLong()

    def process(self, db):
        club_data = db.load_club(self.club_id)
        if club_data is None:
            OutOfSyncMessage(self.client, self.player).send()
            return
        members = db.load_all_players({'ClubID': club_data['ID']})
        AllianceDataMessage(self.client, self.player, members, club_data).send()
