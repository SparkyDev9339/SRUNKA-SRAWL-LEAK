from ByteStream.Writer import Writer


class ShutdownStartedMessage(Writer):
    id = 0

    def encode(self):
        pass
