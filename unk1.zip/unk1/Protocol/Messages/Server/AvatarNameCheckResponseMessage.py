from ByteStream.Writer import Writer
from Logic.Avatar.LogicChangeName import LogicChangeName


class AvatarNameCheckResponseMessage(Writer):
    def __init__(self, client, player, username):
        super().__init__(client)
        self.id = 20300
        self.player = player
        self.username = username

    def encode(self):
        if LogicChangeName.isValid(self, self.username):
            self.writeUInt8(0)
            self.writeInt(0)
        else:
            self.writeUInt8(1)
            self.writeInt(1)
        self.writeString(self.username)
