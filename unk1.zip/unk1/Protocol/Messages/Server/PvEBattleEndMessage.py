from ByteStream.Writer import Writer
from DataBase.MongoDB import MongoDB
import random


class BattleEndMessage(Writer):

    def __init__(self, client, player, b_type, result, rank, players, db: MongoDB):
        super().__init__(client)
        self.id = 23456
        self.player = player
        self.type = b_type
        self.result = result
        self.rank = rank
        self.players = players
        self.db = db
        self.current_player = self.players[0]
        self.bots_players = self.players[1:]

    def encode(self):
        pass
