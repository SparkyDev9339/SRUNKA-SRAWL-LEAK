import time
from ByteStream.Writer import Writer


class JoinableAllianceListMessage(Writer):
    def __init__(self, client, player, db, clubs):
        super().__init__(client)
        self.id = 24304
        self.player = player
        self.db = db
        self.clubs = clubs

    def encode(self):
        self.writeVInt(len(self.clubs))

        current_time = time.time()
        for club in self.clubs:
            members = self.db.load_all_players({'ClubID': club['ID']})
            online_members = []
            for member in members:
                last_seen = current_time - member['LastOnline']
                if last_seen < 15:
                    online_members.append(member)
            self.writeLong(club['ID'])
            self.writeString(club['Name'])
            self.writeDataReference(8, club['BadgeID'])
            self.writeVInt(club['Type'])
            self.writeVInt(len(members))
            self.writeVInt(club['Trophies'])
            self.writeVInt(club['RequiredTrophies'])
            self.writeDataReference(0, 0)
            self.writeString('RU')
            self.writeVInt(len(online_members))
            self.writeVInt(0)
