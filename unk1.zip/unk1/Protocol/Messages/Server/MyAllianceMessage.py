from ByteStream.Writer import Writer


class MyAllianceMessage(Writer):
    def __init__(self, client, player, club_data):
        super().__init__(client)
        self.id = 24399
        self.player = player
        self.club_data = club_data

    def encode(self):
        if self.club_data['ID'] != 0:

            self.writeVInt(0)  # len(self.club_data['Members']))
            self.writeVInt(1)
            self.writeDataReference(25, self.player.club_role)
            self.writeLong(self.club_data['ID'])
            self.writeString(self.club_data['Name'])
            self.writeDataReference(8, self.club_data['BadgeID'])
            self.writeVInt(self.club_data['Type'])
            self.writeVInt(0)  # len(self.club_data['Members']))
            self.writeVInt(self.club_data['Trophies'])
            self.writeVInt(self.club_data['RequiredTrophies'])
            self.writeDataReference(0, 0)
            self.writeString('RU')
            self.writeVInt(0)
            self.writeVInt(0)

        else:
            self.writeVInt(0)
            self.writeVInt(0)
