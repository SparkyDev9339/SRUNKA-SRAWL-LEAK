from ByteStream.Writer import Writer


class BotProfileMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24113
        self.player = player

    def encode(self):
        self.writeLogicLong(0)

        self.writeDataReference(0, 0)

        self.writeVInt(0)
        # for x in self.player_data['UnlockedBrawlers']:
        #     # HeroEntry::encode
        #     self.writeDataReference(16, x)
        #     self.writeDataReference(0, 0)
        #     self.writeVInt(self.player_data['BrawlersTrophies'][str(x)])
        #     self.writeVInt(self.player_data['BrawlersHighestTrophies'][str(x)])
        #    self.writeVInt(10)

        player_stats = {
            '3v3Victories': 0,
            'ExperiencePoints': 0,
            'Trophies': 0,
            'HighestTrophies': 0,
            'UnlockedBrawlersCount': 0,
            'Unknown2': 0,
            'ProfileIconID': 28000001,
            'SoloVictories': 0,
            'BestRoboRumbleTime': 0,
            'BestTimeAsBigBrawler': 0,
            'DuoVictories': 0,
            'HighestBossFightLvlPassed': 0,
            'Unknown4': 0,
            'PowerPlayRank': 0,
            'MostChallengeWins': 0
        }

        self.writeVInt(len(player_stats))
        for x in player_stats:
            self.writeVInt(list(player_stats.keys()).index(x) + 1)
            self.writeVInt(player_stats[x])

        # PlayerDisplayData::encode
        self.writeString('Service Bot')
        self.writeVInt(100)  # Unknown
        self.writeVInt(28000000 + 1)
        self.writeVInt(43000000 + 12)

        self.writeBoolean(False)  # club
        self.writeVInt(0)
