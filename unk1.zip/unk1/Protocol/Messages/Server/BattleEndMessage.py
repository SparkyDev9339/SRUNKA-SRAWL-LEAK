from ByteStream.Writer import Writer
from DataBase.MongoDB import MongoDB
import random

from Logic.Battle.LogicTrophyModifier import LogicTrophyModifier


class BattleEndMessage(Writer):

    def __init__(self, client, player, b_type, result, rank, players, db: MongoDB):
        super().__init__(client)
        self.id = 23456
        self.player = player
        self.type = b_type
        self.result = result
        self.rank = rank
        self.players = players
        self.db = db
        self.current_player = self.players[0]
        self.bots_players = self.players[1:]

    def encode(self):
        solo_balance = [
            {1: 10, 2: 8, 3: 6, 4: 4, 5: 2, 6: 0, 7: -2, 8: -4, 9: -5, 10: -6},     # 0 - 500
            {1: 8, 2: 6, 3: 4, 4: 2, 5: 1, 6: -1, 7: -3, 8: -5, 9: -7, 10: -9},     # 500 - 1000
            {1: 6, 2: 4, 3: 3, 4: 1, 5: -1, 6: -3, 7: -5, 8: -7, 9: -8, 10: -9},    # 1000 - 1500
            {1: 4, 2: 3, 3: 2, 4: 1, 5: -2, 6: -4, 7: -6, 8: -8, 9: -10, 10: -12},  # 1500+
        ]

        duo_balance = [
            {1: 9, 2: 6, 3: 3, 4: 0, 5: -3},     # 0 - 500
            {1: 7, 2: 4, 3: 1, 4: -2, 5: -5},    # 500 - 1000
            {1: 5, 2: 2, 3: 0, 4: -4, 5: -7},    # 1000 - 1500
            {1: 3, 2: 1, 3: -2, 4: -6, 5: -10},  # 1500+
        ]

        three_balance = [
            {0: 8, 1: -4, 2: 0},   # 0 - 500
            {0: 6, 1: -6, 2: 0},   # 500 - 1000
            {0: 4, 1: -9, 2: 0},   # 1000 - 1500
            {0: 3, 1: -12, 2: 0},  # 1500+
        ]

        if len(self.players) == 10:
            if self.bots_players[0]['Team'] == 0:
                battle_mode = 'duo'
            else:
                battle_mode = 'solo'
        else:
            battle_mode = '3vs3'

        if battle_mode == 'solo':
            trophy_balance = solo_balance
        elif battle_mode == 'duo':
            trophy_balance = duo_balance
        else:
            trophy_balance = three_balance

        # Stuff
        brawler_trophies = self.player.brawlers_trophies[str(self.current_player['Brawler'])]
        brawler_high_trophies = self.player.brawlers_high_trophies[str(self.current_player['Brawler'])]

        if brawler_trophies < 500:
            trophy_choose = 0
        elif 500 <= brawler_trophies < 1000:
            trophy_choose = 1
        elif 1000 <= brawler_trophies < 1500:
            trophy_choose = 2
        else:
            trophy_choose = 3

        trophies_got = trophy_balance[trophy_choose][self.result]

        # Extra trophies
        modifier = LogicTrophyModifier.getTrophyModifier()
        if modifier == 0:
            if trophies_got > 0:
                if self.player.vip:
                    trophies_extra = random.randint(1, trophies_got)
                else:
                    trophies_extra = random.randint(0, random.randint(0, trophies_got))
            else:
                trophies_extra = 0
        else:
            trophies_extra = trophies_got * (modifier - 1)

        trophies_got += trophies_extra

        if brawler_trophies + trophies_got < 0:
            trophies_got = 0

        brawler_trophies += trophies_got
        if brawler_trophies > brawler_high_trophies:
            brawler_high_trophies = brawler_trophies

        if str(self.current_player['Brawler']) not in self.player.brawlers_unlocked:
            self.player.brawlers_unlocked.append(str(self.current_player['Brawler']))

        self.player.brawlers_trophies[str(self.current_player['Brawler'])] = brawler_trophies
        self.player.brawlers_high_trophies[str(self.current_player['Brawler'])] = brawler_high_trophies

        self.player.trophies = 0
        for x in self.player.brawlers_trophies.values():
            self.player.trophies += x

        if self.player.trophies > self.player.high_trophies:
            self.player.high_trophies = self.player.trophies
        self.rank = self.result
        if self.result % 2 == 1:
            self.result += 1  # no star tokens
        self.result += 4  # token limit reached

        self.result += 16
        self.player.trophy_anim += trophies_got

        self.db.update_player_account(self.player.token, 'BrawlersUnlocked', self.player.brawlers_unlocked)
        self.db.update_player_account(self.player.token, 'BrawlersTrophies', self.player.brawlers_trophies)
        self.db.update_player_account(self.player.token,
                                      'BrawlersHighestTrophies', self.player.brawlers_high_trophies)
        self.db.update_player_account(self.player.token, 'Trophies', self.player.trophies)
        self.db.update_player_account(self.player.token, 'HighestTrophies', self.player.high_trophies)

        if battle_mode == 'solo' and self.rank == 1:
            self.player.solo_wins += 1
            self.db.update_player_account(self.player.token, 'SoloWins', self.player.solo_wins)

        if battle_mode == 'duo' and self.rank == 1:
            self.player.duo_wins += 1
            self.db.update_player_account(self.player.token, 'DuoWins', self.player.duo_wins)

        if battle_mode == '3vs3' and self.rank == 0:
            self.player.three_wins += 1
            self.db.update_player_account(self.player.token, 'ThreeWins', self.player.three_wins)

        if self.player.club_id != 0:
            club_info = self.db.load_club(self.player.club_id)
            if club_info:
                self.db.update_club_trophies(self.player.club_id)
            else:
                self.player.club_id = 0
                self.db.update_player_account(self.player.token, 'ClubID', self.player.club_id)

        self.writeVInt(self.type)  # Battle End Game Mode
        self.writeVInt(self.rank)  # Result
        self.writeVInt(0)  # Tokens Gained
        if trophies_got >= 0:
            self.writeVInt(trophies_got)  # Trophies Result
        if trophies_got < 0:
            self.writeVInt(-65 - trophies_got)  # Trophies Result
        self.writeVInt(0)  # Unknown (Power Play Related)
        self.writeVInt(0)  # Doubled Tokens
        self.writeVInt(0)  # Double Token Event
        self.writeVInt(0)  # Token Doubler Remaining
        self.writeVInt(0)  # Big Game/Robo Rumble Time
        self.writeVInt(0)  # Unknown (Championship Related)
        self.writeVInt(0)  # Championship Level Passed
        self.writeVInt(0)  # Challenge Reward Type (0 = Star Points, 1 = Star Tokens)
        self.writeVInt(0)  # Challenge Reward Ammount
        self.writeVInt(0)  # Championship Losses Left
        self.writeVInt(0)  # Championship Maximun Losses
        self.writeVInt(0)  # Coin Shower Event
        self.writeVInt(trophies_extra)  # Underdog Trophies
        self.writeVInt(self.result)  # Battle Result Type
        self.writeVInt(-64)  # Championship Challenge Type
        self.writeVInt(0)  # Championship Cleared and Beta Quests

        # Players Array
        self.writeVInt(len(self.players))  # Battle End Screen Players

        self.writeVInt(1)  # Team and Star Player Type
        self.writeDataReference(16, self.current_player['Brawler'])  # Player Brawler
        self.writeDataReference(29, self.current_player['Skin'])  # Player Skin
        self.writeVInt(brawler_trophies)  # Your Brawler Trophies
        self.writeVInt(0)  # Unknown (Power Play Related)
        self.writeVInt(10)  # Your Brawler Power Level
        self.writeBoolean(True)  # HighID and LowID Array
        self.writeInt(0)  # HighID
        self.writeInt(self.player.ID)  # LowID
        self.writeString(self.player.name)  # Your Name
        self.writeVInt(100)  # Player Experience Level
        self.writeVInt(28000000 + self.player.profile_icon)  # Player Profile Icon
        self.writeVInt(43000000 + self.player.name_color)  # Player Name Color

        for bot in self.bots_players:
            if bot['Team'] == 0:
                self.writeVInt(0)  # Team and Star Player Type
            else:
                self.writeVInt(2)  # Team and Star Player Type
            self.writeDataReference(16, bot['Brawler'])  # Bot Brawler
            self.writeVInt(0)  # Bot Skin
            self.writeVInt(0)  # Brawler Trophies
            self.writeVInt(0)  # Unknown (Power Play Related)
            self.writeVInt(10)  # Brawler Power Level
            self.writeBoolean(False)  # HighID and LowID Array
            self.writeString(bot['Name'] + '-ый бот')  # Bot Name
            self.writeVInt(0)  # Player Experience Level
            self.writeVInt(28000000)  # Player Profile Icon
            self.writeVInt(43000000)  # Player Name Color

        # Experience Array
        self.writeVInt(2)  # Count
        self.writeVInt(0)  # Normal Experience ID
        self.writeVInt(0)  # Normal Experience Gained
        self.writeVInt(8)  # Star Player Experience ID
        self.writeVInt(0)  # Star Player Experience Gained

        # Rank Up and Level Up Bonus Array
        self.writeVInt(0)  # Count

        # Trophies and Experience Bars Array
        self.writeVInt(2)  # Count
        self.writeVInt(1)  # Trophies Bar Milestone ID
        self.writeVInt(brawler_trophies - trophies_got)  # Brawler Trophies
        self.writeVInt(brawler_high_trophies - trophies_got)  # Brawler Trophies for Rank
        self.writeVInt(5)  # Experience Bar Milestone ID
        self.writeVInt(0)  # Player Experience
        self.writeVInt(0)  # Player Experience for Level

        self.writeDataReference(28, self.player.profile_icon)  # Player Profile Icon (Unused since 2017)
        self.writeBoolean(False)  # Play Again