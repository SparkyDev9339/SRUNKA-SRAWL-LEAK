import time

from ByteStream.Writer import Writer


class AllianceDataMessage(Writer):

    def __init__(self, client, player, members, club_data):
        super().__init__(client)
        self.id = 24301
        self.player = player
        self.members: list = members
        self.club_data = club_data

    def encode(self):
        if self.club_data['ID'] != 0:
            self.writeVInt(0)
            self.writeLong(self.club_data['ID'])
            self.writeString(self.club_data['Name'].replace('<', '').replace('>', ''))
            self.writeDataReference(8, self.club_data['BadgeID'])
            self.writeVInt(self.club_data['Type'])
            self.writeVInt(len(self.members))
            self.writeVInt(self.club_data['Trophies'])
            self.writeVInt(self.club_data['RequiredTrophies'])
            self.writeDataReference(0, 0)
            self.writeString('RU')
            self.writeVInt(0)
            self.writeVInt(0)

            self.writeString(self.club_data['Description'].replace('<', '').replace('>', ''))
            self.writeVInt(len(self.members))

            current_time = int(time.time())
            for member in self.members:
                self.writeLong(member['ID'])
                self.writeVInt(member['ClubRole'])
                self.writeVInt(member['Trophies'])
                self.writeVInt(0)  # player status: last online a hour ago
                self.writeVInt(0)
                self.writeVInt(0)

                self.writeString(member['Name'])
                self.writeVInt(100)
                self.writeVInt(28000000 + member['ProfileIcon'])
                self.writeVInt(43000000 + member['NameColor'])

        else:
            self.writeVInt(2)
