import time
from Utils.Helpers import Helpers
from ByteStream.Writer import Writer
import psutil


class ServerStatisticsMessage(Writer):
    id = 80402

    def encode(self):
        memory_usage = psutil.virtual_memory()
        disk_usage = psutil.disk_usage('/')
        process_count = len(psutil.pids())

        # Memory usage
        self.writeLong(int(memory_usage.total / 1024))  # in KB
        self.writeLong(int(memory_usage.used / 1024))
        self.writeLong(int(memory_usage.available / 1024))
        self.writeVInt(round(memory_usage.percent))

        # Disk usage
        self.writeLong(int(disk_usage.total / 1024))
        self.writeLong(int(disk_usage.used / 1024))
        self.writeLong(int(disk_usage.available / 1024))
        self.writeVInt(round(disk_usage.percent))

        self.writeVInt(process_count)  # process count

        self.writeLong(int(time.time() - psutil.boot_time()))  # running for X seconds

        self.writeInt(Helpers.connected_clients['ClientsCount'])  # online clients
