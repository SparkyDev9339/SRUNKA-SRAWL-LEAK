import string
import random
from colorama import Fore

class Helpers:
    connected_clients = {"ClientsCount": 0, "Clients": {}, "ShutdownStarted": False}

    yellow = Fore.YELLOW
    green = Fore.GREEN
    blue = Fore.LIGHTBLUE_EX
    cyan = Fore.CYAN
    red = Fore.RED

    def randomToken(self):
        lettersAndDigits = string.ascii_letters + string.digits
        return ''.join(random.choice(lettersAndDigits) for i in range(40))

    def randomID(self, length = 8):
        return int(''.join([str(random.randint(0, 9)) for _ in range(length)]))

    def randomMapID(self):
        return random.randint(1, 2147483647)

    def get_box_type(self, id):
        if id == 5:  # Brawl Box
            return 10
        elif id == 4:  # Big Box
            return 12
        elif id == 3:  # Shop Mega Box
            return 11
        elif id == 1:  # Shop Big Box
            return 12

    def load_account(self, player_data):
        self.player.name_set = player_data['NameSet']
        self.player.name = player_data['Name']
        self.player.trophies = player_data['Trophies']
        self.player.resources = player_data['Resources']
        self.player.token_doubler = player_data['TokenDoubler']
        self.player.high_trophies = player_data['HighestTrophies']
        self.player.trophy_reward = player_data['TrophyRoadReward']
        self.player.profile_icon = player_data['ProfileIcon']
        self.player.name_color = player_data['NameColor']
        self.player.theme_id = player_data['ThemeID']
        self.player.brawlers_unlocked = player_data['UnlockedBrawlers']
        self.player.brawlers_trophies = player_data['BrawlersTrophies']
        self.player.brawlers_high_trophies = player_data['BrawlersHighestTrophies']
        self.player.selected_skins = player_data['SelectedSkins']
        self.player.home_brawler = player_data['HomeBrawler']
        self.player.starpower = player_data['StarPower']
        self.player.gadget = player_data['Gadget']
        self.player.club_id = player_data['ClubID']
        self.player.club_role = player_data['ClubRole']
        self.player.telegram_id = player_data['TelegramID']
        self.player.vip = player_data['Vip']
        self.player.last_online = player_data['LastOnline']
        self.player.is_banned = player_data['IsBanned']
        self.player.ban_reason = player_data['BanReason']
        self.player.solo_wins = player_data['SoloWins']
        self.player.duo_wins = player_data['DuoWins']
        self.player.three_wins = player_data['ThreeWins']
        self.player.next_name_change = player_data['NextNameChange']

    def load_club(self, club_data):
        try:
            self.player.message_tick = club_data['Messages'][-1]['Tick'] + 1
        except:
            pass

    def reload_player(self, db):
        Helpers.load_account(self, db.load_player_account(self.player.token))
