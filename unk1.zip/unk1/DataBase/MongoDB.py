import time

import pymongo
import datetime
from DataBase.MongoUtils import MongoUtils
from Logic.Player import Player


class MongoDB:
    def __init__(self, conn_str):
        self.player = Player
        self.client = pymongo.MongoClient(conn_str, serverSelectionTimeoutMS=5000)
        self.client.server_info()
        self.mongo_utils = MongoUtils()

        self.database = self.client['luckybrawl']
        self.players = self.database['players']
        self.clubs = self.database['clubs']

        self.data = {
            'Name': 'Guest',
            'NameSet': False,
            'Trophies': Player.trophies,
            'HighestTrophies': Player.trophies,
            'Resources': Player.resources,
            'TokenDoubler': 0,
            'HomeBrawler': 0,
            'TrophyRoadReward': 300,
            'ProfileIcon': 0,
            'NameColor': 0,
            'ThemeID': 11,
            'UnlockedBrawlers': Player.brawlers_unlocked,
            'BrawlersTrophies': Player.brawlers_trophies,
            'BrawlersHighestTrophies': Player.brawlers_high_trophies,
            'UnlockedSkins': Player.unlocked_skins,
            'SelectedSkins': Player.selected_skins,
            'SelectedBrawler': 0,
            'StarPower': Player.starpower,
            'Gadget': Player.gadget,
            'ClubID': 0,
            'ClubRole': 1,
            'TimeStamp': str(datetime.datetime.now()),
            'SoloWins': 0,
            'DuoWins': 0,
            'ThreeWins': 0,
            'Vip': False,
            'LastOnline': int(time.time()),
            'IsBanned': False,
            'BanReason': '',
            'TelegramID': 0,
            'NextNameChange': 0,
        }

        self.club_data = {
            'Name': '',
            'Description': '',
            'BadgeID': 0,
            'Type': 0,
            'Trophies': 0,
            'RequiredTrophies': 0,
            'Messages': [],
            'BannedPlayers': {},
        }

    def create_player_account(self, id, token):
        auth = {
            'ID': id,
            'Token': token,
        }

        auth.update(self.data)

        self.mongo_utils.insert_data(self.players, auth)

    def load_player_account(self, token):
        query = {"Token": token}
        result = self.mongo_utils.load_document(self.players, query)
        if result:
            missing_data = {}
            for key, value in self.data.items():
                if key not in result:
                    missing_data[key] = value
            if missing_data:
                self.mongo_utils.update_info_document(self.players, query, missing_data)
                result = self.mongo_utils.load_document(self.players, query)

            return result

    def load_player_account_by_id(self, id):
        query = {"ID": id}
        result = self.mongo_utils.load_document(self.players, query)

        if result:
            return result

    def update_player_account(self, token, item, value):
        query = {"Token": token}
        self.mongo_utils.update_document(self.players, query, item, value)

    def update_all_players(self, query, item, value):
        self.mongo_utils.update_all_documents(self.players, query, item, value)

    def delete_all_players(self, args):
        self.mongo_utils.delete_all_documents(self.players, args)

    def delete_player(self, token):
        query = {"Token": token}
        self.mongo_utils.delete_document(self.players, query)

    def load_all_players(self, args):
        result = self.mongo_utils.load_all_documents(self.players, args)

        return result

    def load_all_players_sorted(self, args, element):
        result = self.mongo_utils.load_all_documents_sorted(self.players, args, element)

        return result

    def create_club(self, id, data):
        auth = {
            'ID': id,
        }

        auth.update(data)

        self.mongo_utils.insert_data(self.clubs, auth)

    def update_club(self, id, item, value):
        query = {"ID": id}
        self.mongo_utils.update_document(self.clubs, query, item, value)

    def update_club_trophies(self, id):
        if id != 0:
            trophies = 0
            members = self.load_all_players({'ClubID': id})
            for member in members:
                trophies += member['Trophies']
            self.update_club(id, 'Trophies', trophies)

    def load_club(self, id):
        query = {"ID": id}
        result = self.mongo_utils.load_document(self.clubs, query)

        if result:
            missing_data = {}
            for key, value in self.club_data.items():
                if key not in result:
                    missing_data[key] = value
            if missing_data:
                self.mongo_utils.update_info_document(self.clubs, query, missing_data)
                result = self.mongo_utils.load_document(self.clubs, query)

            return result

    def load_all_clubs_sorted(self, args, element):
        result = self.mongo_utils.load_all_documents_sorted(self.clubs, args, element)

        return result

    def load_all_clubs(self, args):
        result = self.mongo_utils.load_all_documents(self.clubs, args)

        return result

    def delete_club(self, id):
        query = {"ID": id}
        self.mongo_utils.delete_document(self.clubs, query)
