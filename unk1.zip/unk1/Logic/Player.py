import json
import time
from Utils.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards


class Player:
    config = open('config.json', 'r')
    settings = json.load(config)

    skins_id = Skins().get_skins_id()
    brawlers_id = Characters().get_brawlers_id()

    ID = 0
    token = None

    trophies = 0
    tickets = 100
    gems = 1
    resources = [
        {'ID': 1, 'Amount': 99999},  # brawl box tokens
        {'ID': 8, 'Amount': 0},
        {'ID': 9, 'Amount': 99999},  # big box tokens
        {'ID': 10, 'Amount': 999},  # starpoints
    ]
    high_trophies = 0
    trophy_reward = 300
    profile_icon = 0
    name_color = 0
    selected_brawler = 0
    region = 'RU'
    content_creator = "TG: @unkbrawl"
    name_set = False
    name = 'Guest'
    map_id = 0
    use_gadget = True
    starpower = 76
    gadget = 255
    home_brawler = 0
    home_skin = 0
    leaderboard_type = 0
    leaderboard_is_global = False
    token_doubler = 0
    theme_id = 10
    telegram_id = 0
    maintenance = settings['Maintenance']
    maintenance_time = settings['SecondsTillMaintenanceOver']
    patch = settings['Patch']
    patch_url = settings['PatchURL']
    patch_sha = Fingerprint.loadFinger("GameAssets/fingerprint.json")
    update_url = settings['UpdateURL']

    vip = False
    ban_code = 0
    last_online = int(time.time())
    solo_wins = 0
    duo_wins = 0
    three_wins = 0
    next_time_change = 0

    err_code = 1

    delivery_items = {}
    box_rewards = {}

    trophy_anim = 0

    db = None

    battle_tick = 0

    unlocked_skins = skins_id

    selected_skins = {}
    for id in brawlers_id:
        selected_skins.update({f"{id}": 0})

    brawlers_unlocked = [0]

    brawlers_card_id = []
    for x in brawlers_unlocked:
        brawlers_card_id.append(Cards().get_unlock_by_brawler_id(x))

    brawlers_spg = Cards().get_spg_id()

    brawlers_trophies = {}
    for x in brawlers_id:
        brawlers_trophies.update({str(x): 0})

    brawlers_high_trophies = {}
    for x in brawlers_id:
        brawlers_high_trophies.update({str(x): 0})

    club_id = 0
    club_role = 0

    message_tick = 0

    clients = {}
