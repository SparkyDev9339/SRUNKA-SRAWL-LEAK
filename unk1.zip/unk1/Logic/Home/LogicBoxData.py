import random
from Logic.Player import Player


class LogicBoxData:
    player: Player

    def randomize(self, choose):
        if choose == 10:
            count = 1
        elif choose == 11:
            count = 10
        else:  # think big box, id 12
            count = 3

        golds = []  # not an list[dict], its list[int]
        brawlers = []
        total_box = []

        for reward in [LogicBoxData.get_mini_box(self) for _ in range(count)]:
            if reward['Value'] == 7:
                golds.append(reward['Amount'])
            else:
                brawlers.append(reward)

        total_box.append({'Amount': sum(golds), 'DataRef': [0, 0], 'Value': 7})
        total_box.extend(brawlers)

        return total_box

    def get_mini_box(self):
        locked_brawlers = []
        for brawler in self.player.brawlers_id:
            if brawler not in self.player.brawlers_unlocked:
                locked_brawlers.append(brawler)

        chance = random.randint(1, 100)
        if locked_brawlers and chance < 8:
            unlocked_brawler = random.choice(locked_brawlers)
            self.player.brawlers_unlocked.append(unlocked_brawler)
            self.player.db.update_player_account(
                self.player.token, 'UnlockedBrawlers', self.player.brawlers_unlocked)
            return {'Amount': 1, 'DataRef': [16, unlocked_brawler], 'Value': 1}

        gold = random.randint(20, 50)
        self.player.resources[1]['Amount'] += gold
        self.player.db.update_player_account(self.player.token, 'Resources', self.player.resources)

        return {'Amount': gold, 'DataRef': [0, 0], 'Value': 7}

    def get_bonus(self):
        chance = random.randint(1, 100)
        if chance < 30:
            self.player.token_doubler += 200
            self.player.db.update_player_account(self.player.token, 'TokenDoubler', self.player.token_doubler)
            return {'Amount': 200, 'DataRef': [0, 0], 'Value': 2}
        elif chance < 40:
            tickets = random.randint(1, 35)
            self.player.tickets += tickets
            self.player.db.update_player_account(self.player.token, 'Tickets', self.player.tickets)
            return {'Amount': tickets, 'DataRef': [0, 0], 'Value': 3}
