import time


class LogicChangeName:
    @staticmethod
    def isValid(self, name):
        if self.player.name_color == 12:
            return False
        if time.time() < self.player.next_name_change:
            return False
        if 'albert' in name.lower() or \
            'nalinor' in name.lower() or \
                'service bot' in name.lower():
            return False
        return 2 <= len(name) <= 20
