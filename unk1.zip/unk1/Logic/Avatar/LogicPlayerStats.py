class LogicPlayerStats:

    @staticmethod
    def getPlayerStats(accountData):
        playerStats = {
            '3v3Victories': accountData['ThreeWins'],
            'ExperiencePoints': 0,
            'Trophies': accountData['Trophies'],
            'HighestTrophies': accountData['HighestTrophies'],
            'UnlockedBrawlersCount': len(accountData['UnlockedBrawlers']),
            'Unknown2': 0,
            'ProfileIconID': 28000000 + accountData['ProfileIcon'],
            'SoloVictories': accountData['SoloWins'],
            'BestRoboRumbleTime': 0,
            'BestTimeAsBigBrawler': 0,
            'DuoVictories': accountData['DuoWins'],
            'HighestBossFightLvlPassed': 21,
            'Unknown4': 0,
            'PowerPlayRank': 1,
            'MostChallengeWins': 0
        }
        return playerStats
