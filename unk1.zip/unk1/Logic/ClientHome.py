from Logic.Home.LogicDailyData import LogicDailyData
from Logic.Home.LogicConfData import LogicConfData


class LogicClientHome:
    def encode(self):
        LogicDailyData.encode(self)
        LogicConfData.encode(self)

        self.writeLong(self.player.ID)

        self.writeVInt(0)  # Notifications factory
        for i in range(0):
            self.writeInt(1)
            self.writeVInt(2)
            self.writeInt(81)
            self.writeString("dick!")
            self.writeVInt(1)

        self.writeVInt(0)

        self.writeUInt8(0)  # Unknown
