from datetime import datetime


class LogicTrophyModifier:
    @staticmethod
    def getTrophyModifier():
        today = datetime.utcnow()
        from_m = datetime(2021, 11, 1, 8)
        to1_m = datetime(2021, 11, 2, 8)
        to_m = datetime(2021, 11, 4, 8)
        if from_m.timestamp() < today.timestamp() < to1_m.timestamp():
            return 3
        elif from_m.timestamp() < today.timestamp() < to_m.timestamp():
            return 2
        return 0
